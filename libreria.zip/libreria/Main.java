package libreria;
import usuarios.Cliente;
import utils.Rol;
public class Main {

    /*
    C: CREATE
    R: READ
    U: UPDATE
    D: DELETE
    */
    
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.iniciarSesión();
        libreria.Libro.registrarLibro();
    }
    
}
