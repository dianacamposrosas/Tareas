package utils;
public enum Rol {
    CLIENTE,
    ASISTENTE,
    GERENTE
}
