package utils;

public interface EmpleadoUtils {
    
    public void checarEntrada();
    
    public void checarSalida();

}
