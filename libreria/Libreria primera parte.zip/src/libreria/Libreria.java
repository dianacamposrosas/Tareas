package libreria;
import libreria.Usuarios.Cliente;
import utils.Rol;
public class Libreria {

    //ejercicio/librería/parte1/unidad3
    public static void main(String[] args) {
        Cliente clientePrueba = new Cliente ("Juan", "Rivera", "4432344234");
        System.out.println(clientePrueba.toString());
    }
    
}
